$(function() {  
    $("html").niceScroll({cursorcolor:"#17bed2"}); 
});

/* Set the width of the side navigation to 250px */
function openNav() {
    document.getElementById("myTopnav").style.height = "100%";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
    document.getElementById("myTopnav").style.height = "0";
}
 