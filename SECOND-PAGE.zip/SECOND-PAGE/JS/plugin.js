/** global $ ,**/

$(function(){
	
	$(".rotate").textrotator({
	animation: "fade" ,
		seperator: "," ,
		speed: 1100
		
	});
	
	$(window).scroll(function(){
		if( $(this).scrollTop() > 100 ){
			$(".navbar").addClass("opaque");
		}else{
			$(".navbar").removeClass("opaque");
		}
	});
	
	    $('a[href="#search"]').on('click', function(event) {
        event.preventDefault();
        $('#search').addClass('open');
        $('#search > form > input[type="search"]').focus();
    });
    
    $('#search, #search button.close').on('click keyup', function(event) {
        if (event.target == this || event.target.className == 'close' || event.keyCode == 27) {
            $(this).removeClass('open');
        }
    });
   
	
	 $(".dropdown").hover(  
		
	function() {
                $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                $(this).toggleClass('open');
                $('b', this).toggleClass("glyphicon glyphicon-menu-down");                
            },
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
                $(this).toggleClass('open');
                $('b', this).toggleClass("glyphicon glyphicon-menu-down");                
            });
		
});