# Project Overview

location: <a href="https://github.com/udacity/frontend-nanodegree-feedreader">Click Here</a>


##  Tests That Were Implemented

- Tests  allfeeds  defined and not empty 
- Tests  allFeeds  url and  not empty
- Tests  allFeeds  name and  not empty 
- Searches the class of menu-hidden in the body tag 
- Toggles on click event
-Tests  the loadFeed function has at least a single 
- Tests to see if  entry are not equal


##  How to Run Appilcation

-open the index.html file in a browser.project you are given a web-based application that reads RSS feeds.The original developer of this application clearly saw the value in testing, they've already included [Jasmine](http://jasmine.github.io/) and even started writing their first test suite! Unfortunately, they decided to move on to start their own company and we're now left with an application with an incomplete test suite. That's where you come in.








