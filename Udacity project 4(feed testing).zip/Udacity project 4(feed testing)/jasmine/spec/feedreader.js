$(function() {

    describe('RSS Feeds', function() {
		
        // allFeeds variable has been defined and not empty
        it('feed defined', function() {
            expect(allFeeds).toBeDefined();
            expect(allFeeds).toBeTruthy();
            expect(allFeeds.length).not.toBe(0);
        });


        //URL defined and not empty
		it('URL defined', function(){
            for (var index in allFeeds) 
                expect(allFeeds[index].url).toBeDefined();
                expect(allFeeds[index].url).toBeTruthy();
				expect(allFeeds[index].url.length).not.toBe(0);
			
		});

        //name defined and not empty
		it('name defined', function(){
            for (var index in allFeeds) 
                expect(allFeeds[index].name).toBeDefined();
                expect(allFeeds[index].name).toBeTruthy();
				expect(allFeeds[index].name.length).not.toBe(0);
		
		});
		
    });
	
	
	describe('The menu', function(){
		
		//menu element defined
		it('menu element', function(){
            expect($('body').hasClass('menu-hidden')).toEqual(true);
		});
		
		// Toggles  click menu 
        it(' toggle event', function () {
            $('.menu-icon-link').trigger('click');
            expect($('body').hasClass('menu-hidden')).toBe(false);
            $('.menu-icon-link').trigger('click');
            expect($('body').hasClass('menu-hidden')).toBe(true);
        });
		
	});
    

    
    describe('Initial Entries', function () {

        // function for an asynchronous request 
        beforeEach(function(done) {
            loadFeed(0, done);
        });
        

        //the loadFeed function has at least a single 
        it(' if feed has at least a single entry', function (done) {
            expect($('.feed .entry').length).not.toBe(0);
            expect($('.feed .entry').length).toBeGreaterThan(0);
			done();
        });
    });
	
    describe('Feed Selection', function() {
      
        var first, second;

         beforeEach(function(done) {
            loadFeed(0,function(){
             
                first = $('.feed').html();
                loadFeed(1,done);
            });
        });

         it('different items', function(done){
           
            second = $('.feed').html();
            expect(first).not.toEqual(second);

            done();
        });
    });

}());
