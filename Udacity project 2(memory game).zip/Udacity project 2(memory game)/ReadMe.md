# Memory Game Project

## What is the Memory Game
it is game built to test aplayers memory. There's a group of card pictures. Match cards in less time with less moves


## Instructions
- Click on a card
- Keep cards in your mind and working your memory to remember each matched card.
- Match cards with less moves and in faster time


## How I built the Memory Game
I manipulated the DOM with Vanilla JS, HTML and also styled the game
- created a group of cards that shuffles when game is refreshed
- created a counter to count the number of moves of player and timer 
- create a game over modal
