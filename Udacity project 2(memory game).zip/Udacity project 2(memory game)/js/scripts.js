var cards = document.querySelectorAll('.card');
var flipping = false;
var lockBoard = false;
var firstCard, secondCard;

// declaring move variable
var count=0;
var moves = document.querySelector(".moves");

// declare variables for star icons
var stars = document.querySelectorAll(".fa-star");
var starsList = document.querySelectorAll(".stars li");

// declaring timer value
var timer = new Timer();

// Get the modal
var modal = document.getElementById('myModal');
 
 // close icon in modal
var closebutton = document.querySelector(".close-game");


shuffling();

// flipping the card
function flipCard() {
    "use strict";
    
 timer.start({ startValues: {minutes: 0, seconds: 0 } });
    
 if (lockBoard)  return ;
  if (this === firstCard) return;
    
  this.classList.add('flip');

    // declare the first clicked card and second 
  if (!flipping) {
    flipping = true;
    firstCard = this;
  }else{
      flipping=false;
      secondCard = this;
      
      checkMatching();      
  }
}


function checkMatching(){
     var isMatch = firstCard.dataset.type === secondCard.dataset.type;
     //// if the card matching
    isMatch ? disableCards() : unflipCards();
    moving();
}

function disableCards() {
	
	 //If it is a match this will disable the matched cards
  var first = firstCard;  //Needed for fade Timeout
 var second = secondCard;  //Needed for fade Timeout
  
  setTimeout(function(){
    first.classList.add('flipcards');
    second.classList.add('flipcards');
    checkgameover(); //Checks to see if all cards have matched and been faded
  }, 750);
	
  firstCard.removeEventListener('click', flipCard);
  secondCard.removeEventListener('click', flipCard);
	resetBoard();
}

function unflipCards() {
    lockBoard = true;
  setTimeout(function(){
    firstCard.classList.remove('flip');
    secondCard.classList.remove('flip');
       lockBoard = false;
	  resetBoard();
  }, 500);
}

function resetBoard() {
    "use strict";
  [flipping, lockBoard] = [false, false];
  [firstCard, secondCard] = [null, null];
}

//count the number of moves
function moving(){
         count++;
          moves.innerHTML =count;  
    
	
    // star rating method
    if (count > 8 && count < 12){
        for( i= 0; i < 8; i++){
            if(i > 1){
                stars[i].style.visibility = "collapse";
            }
        }
    }
    else if (count > 12){
        for( i= 0; i < 8; i++){
            if(i > 0){
                stars[i].style.visibility = "collapse";
            }
        }
    }
}

//lib/easytimer/dist/easytimer.min.js
       timer.addEventListener('secondsUpdated', function (e) {
    $('#basicUsage').html(timer.getTimeValues().toString(['minutes', 'seconds']));
}); 

// restart all the game
function resetGame() {
  Array.from(cards).forEach(card => card.classList.remove('fadeOutDown'));
  window.location.reload(); 
  }
    
// card arrange random every start game
function shuffling(){
    "use strict";
(function shuffle() {
  cards.forEach(card => {
    let randomPos = Math.floor(Math.random() * 12);
    card.style.order = randomPos;
  });
})();}
 
// the event the game work
cards.forEach(card => card.addEventListener('click', flipCard));

 // @description close icon on modal
function closeModal(){
    closebutton.addEventListener("click", function(e){
        modal.style.display = "none";;
    });
}

// @desciption for user to play Again 
function Replay(){
     modal.style.display = "none";;
    resetGame();
}

// Testing game over //

function checkgameover(){
var flipcards = 0;
  
  for (var i = 0; i < cards.length; i++){
    if(cards[i].classList.contains('flipcards')){
      flipcards++; 
    }
  }
  
  // Check to see if game over by comparing faded cards
  if(flipcards == 16){
	  timer.stop();
      congratulations();     
  }
}


// @description congratulations when all cards match, show modal and moves, time and rating
function congratulations(){
	
	// show congratulations modal
         modal.style.display = "block";
	 
	// declare star rating variable
        var starRating = document.querySelector(".stars").innerHTML;
      
	 //showing move, rating, time on modal
    document.getElementById("Moves").innerHTML = count;
	document.getElementById("starRating").innerHTML = starRating;
	
        //closeicon on modal
        closeModal();
}






