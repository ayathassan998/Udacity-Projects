$(function() {  
    $("html").niceScroll({cursorcolor:"#009688"}); 
});



 