# Classic Arcade Game Clone Project
  download them from [here](https://github.com/udacity/frontend-nanodegree-arcade-game)
  
## What is the Memory Game
 its classic game to reach the beach without colligion the enemies.
  Open 'index.html' to run the app and try plaing.
  
## Instructions
- move player to 4 directions left , right , up , down.
- if you go to the beach in the other side you win without colligion the enemies.
- If you win you can restart the game .