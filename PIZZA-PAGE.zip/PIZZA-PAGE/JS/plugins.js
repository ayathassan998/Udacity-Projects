$(function() {  
    $("html").niceScroll({cursorcolor:"#17bed2"}); 
});




 