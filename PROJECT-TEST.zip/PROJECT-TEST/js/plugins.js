/*global console, alert, prompt ,interval*/

$(document).ready(function(){
$('.myslide').carousel({
	interval: 1000
});

		

    $("html").niceScroll();

	
	
	
});

/***
document.getElementById("myslide").ready.interval="1000";

document.getElementById('html').ready.$anchorScroll=
***/
